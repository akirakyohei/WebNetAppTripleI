﻿using System;
namespace ProjectOp.DTO
{
    public class AchievementDTO
    {
        public AchievementDTO()
        {
        }
        public string achieve { get; set; }
    }
}
